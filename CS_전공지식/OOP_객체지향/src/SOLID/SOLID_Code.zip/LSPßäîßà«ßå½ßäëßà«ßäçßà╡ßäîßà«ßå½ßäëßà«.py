class Animal:
    def speak(self):
        pass

class Cat(Animal):
    def speak(self):
        print("meow")


class BlackCat(Cat):
    def speak(self):
        print("black meow")

class Fish(Animal) :
    def speak(self):
        raise Exception("Fish cannot speak")

def speak(_animal: Animal):
    _animal.speak()


animal = Cat()
speak(animal);
animal = BlackCat()
speak(animal);
animal = Fish();
speak(animal);